package com.Prestashop;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

public class InputLoginAndPassword extends Settings {


    @Test
    public void scriptA() {

        driver.get("http://prestashop-automation.qatestlab.com.ua/admin147ajyvk0/");

        driver.findElementById("email").sendKeys("webinar.test@gmail.com");
        driver.findElementById("passwd").sendKeys("Xcg7299bnSmMuRLp9ITw");
        driver.findElementByName("submitLogin").click();

        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElementById("employee_infos").click();
        driver.findElementById("header_logout").click();
    }

    @Test
    public void scriptB() {

        driver.get("http://prestashop-automation.qatestlab.com.ua/admin147ajyvk0/");
        driver.findElementById("email").sendKeys("webinar.test@gmail.com");
        driver.findElementById("passwd").sendKeys("Xcg7299bnSmMuRLp9ITw");
        driver.findElementByName("submitLogin").click();
        driver.findElementById("tab-AdminDashboard").click();


        driver.findElementById("subtab-AdminOrders").click();  // це мало би нажати меню Заказы, та чогось не нажимає, мені треба всі меню нажати

    }


}
